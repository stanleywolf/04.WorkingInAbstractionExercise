﻿using System;
using System.Collections.Generic;
using System.Text;


public class Tires
{
    public double Tire1Presure { get; set; }
    

    public Tires(double tire1Presure)
    {
        Tire1Presure = tire1Presure;
        
    }
}